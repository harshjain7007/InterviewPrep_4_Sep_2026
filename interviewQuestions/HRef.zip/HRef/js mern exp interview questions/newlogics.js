const data = {
  id: "12345",
  name: "John Doe",
  email: "johndoe@example.com",
  profile: {
    age: 30,
    gender: "Male",
    address: {
      street: "123 Main St",
      city: "New York",
      state: "NY",
      postalCode: "10001",
      country: "USA",
    },
  },
  settings: {
    notifications: {
      email: true,
      sms: false,
      push: true,
    },

    theme: {
      color: "dark",

      fontSize: "medium",
    },
  },
};

let flatData = {};

function flatObject(obj, key) {
  if (typeof obj == "object") {
    Object.keys(obj).forEach((singleKey) => {
      flatObject(obj[singleKey], key ? key + "-" + singleKey : singleKey);
    });
  } else {
    flatData[key] = obj;
  }
}

flatObject(data, "");

console.log(flatData)``;

// fetch data from any api more then 100+ data they have  print data inside table and applying caching
// getting complex data from APIs and design  its interfaces from this data
// Jest try it’s also free for components testing
// try to use useMemo & useCallback & React.Memo function
// create react app  call api with react-query get data print inside table pagination use caching

// --------------  create pollifill for Find method of array --- :-
if (!Array.prototype.find) {
  Array.prototype.find = function (callback, thisArg) {
    if (this == null) {
      throw new TypeError("Array.prototype.find called on null or undefined");
    }
    if (typeof callback !== "function") {
      throw new TypeError(callback + " is not a function");
    }

    const array = Object(this);
    const len = array.length >>> 0;

    for (let i = 0; i < len; i++) {
      if (i in array) {
        const element = array[i];
        if (callback.call(thisArg, element, i, array)) {
          return element;
        }
      }
    }
    return undefined;
  };
}

// ----  Compressed string :-
function compressString(str) {
  let newStr = "";
  let count = 1;

  for (let i = 0; i < str.length; i++) {
    // Check if the next character is the same as the current one
    if (i < str.length - 1 && str[i] === str[i + 1]) {
      count++;
    } else {
      // Append the current character to the new string
      newStr += str[i];
      // Append the count if it's greater than 1
      if (count > 1) {
        newStr += count;
      }
      // Reset the count
      count = 1;
    }
  }
  return newStr;
}

console.log(compressString("haaarsasshh")); // Output: ha3rsas2h2

// ----  Find out's the time complexity of loops :-----
let arr = [];
for (let i = 0; i < 5; i++) {
  for (let j = 0; j < 5; j++) {
    arr.push(i * j);
  }
}
// o/p :-
// Outer loop: 5 iterations
// Inner loop: 5 iterations per each iteration of the outer loop
// Total iterations = 5 (outer loop) * 5 (inner loop) = 25 iterations
// The time complexity is 𝑂(𝑛2) O(n 2) where 𝑛 is the number of iterations for each loop. so n square mean 25
let count = 0;
let N = 10; // this could be any input size
for (let i = 0; i < N; i++) {
  count++;
} // time complexity of that loop is O(N)
for (let i = 0; i < 5; i++) {
  count++;
} //  time complexity of that loop is O(1) which denotes constant time complexity. It means the runtime does not change with varying input sizes; it remains constant.

// -----  find out the common elements of these two array's  TRY to use less time complexity --- :-
let array1 = [
  { id: 1, name: "john" },
  { id: 2, name: "doe" },
  { id: 3, name: "json" },
];
let array2 = [
  { id: 2, name: "aaa" },
  { id: 3, name: "bbb" },
  { id: 4, name: "ccc" },
];
// --- using reduce and find like using build in methods
function fun(arr1, arr2) {
  let commonIds = arr1.reduce((acc, curElem) => {
    let find = arr2.find((elem) => elem.id === curElem.id);
    if (find) {
      acc.push(find);
    }
    return acc;
  }, []);
  return commonIds;
}
console.log(fun(array1, array2)); // Time complexity O(n*m)  where n is number of elements of arr1, m is number is elements of arr2

// -----------  Fibnacchi series not more than given value -------
function fib(num) {
  if (num === 1) {
    return [0, 1];
  } else {
    let result = fib(num - 1);
    if (result[result.length - 1] + result[result.length - 2] < num) {
      result.push(result[result.length - 1] + result[result.length - 2]);
    }
    return result;
  }
}
let nu = 50;
console.log(fib(nu));

// ----------- Fibonacchi series nth term using recursion --------
function fib(num) {
  if (num === 0) {
    return [0, 1];
  } else {
    let result = fib(num - 1);
    result.push(result[result.length - 1] + result[result.length - 2]);
    return result;
  }
}
let n = 10;
console.log(fib(n));

// --------  Throttle Example  ------------
function throttle(func, delay) {
  let lastCalledTime = 0;
  return function (...args) {
    const now = Date.now();
    console.log(now);
    if (now - lastCalledTime >= delay) {
      func.apply(this, args);
      lastCalledTime = now;
    }
  };
}

function doSomething() {
  console.log("Doing something...");
}

const throttledFunction = throttle(doSomething, 1000); // Throttle to once per second

// Call the throttled function multiple times
throttledFunction(); // Output: "Doing something..."
setTimeout(() => throttledFunction(), 500); // This call will be ignored due to throttling
setTimeout(() => throttledFunction(), 500); // This call will be ignored due to throttling
setTimeout(() => throttledFunction(), 1000); // This call will be executed after 1 second

//---------- Deboce example in javaScropt  :------
function debounce(func, delay) {
  let timeoutId;

  return function (...args) {
    // const context = this;
    //     const args = arguments;

    if (timeoutId) clearTimeout(timeoutId);

    timeoutId = setTimeout(() => {
      func.apply(this, args);
    }, delay);
  };
}

// Example function to be debounced
function processInput(value) {
  console.log("Processing input:", value);
}

// Debounce the function with a delay of 500 milliseconds
const debouncedProcessInput = debounce(processInput, 500);

// Simulate multiple input events
debouncedProcessInput("Input 1");
debouncedProcessInput("Input 2");
debouncedProcessInput("Input 3");
debouncedProcessInput("Input 4");
debouncedProcessInput("Input 5"); //  o/p is Input 5

// Only the last input will be processed after the delay

// ---------- write a custom functipon fro DeepClone Object and DeepClone Array ---------
let obj = {
  name: "harsh",
  age: 24,
  childObj: {
    name: "nyn",
  },
  childArr: [1, 2, 3],
};

function deepClone(obj) {
  if (obj === null || typeof obj !== "object") {
    // If obj is null or not an object, return it as is
    return obj;
  }

  // Create an empty object or array to store the cloned properties
  const clone = Array.isArray(obj) ? [] : {};

  // logic for  cloneing
  // Iterate over each property of the object
  // for (let key in obj) {
  //   if (obj.hasOwnProperty(key)) {
  //     // Recursively clone nested objects or arrays
  //     clone[key] = deepClone(obj[key]);
  //   }
  // }

  // logic for nested deep cloneing
  if (obj.hasOwnProperty(key)) {
    if (typeof obj[key] === "object" || Array.isArray(obj[key])) {
      clone[key] = fun(obj[key]);
    } else {
      clone[key] = obj[key];
    }
  }

  return clone;
}
let duplicateObj = deepClone(obj);
duplicateObj.name = "ncs";
duplicateObj.childArr[3] = "jain";
duplicateObj.childObj.name = "KKK";
console.log(duplicateObj, obj);

// ---  findout same value and keys of two objects
function fun(obj1, obj2) {
  let result = {};
  for (let i in obj1) {
    for (let j in obj2) {
      if (i === j) {
        if (obj1[i] === obj2[j]) {
          result[i] = obj1[i];
        }
      }
    }
  }
  return result;
}
const string1 = { a: 1, b: 4, c: 5, d: 6, e: 7 };
const string2 = { a: 2, c: 5, e: 7, f: 4 };
console.log(fun(string1, string2)); // { c: 5, e: 7 }

// write a custum function to flat array program
let arrs = [1, [2], [[3, 4]], [9, [8, 7, [[23]]]]];

function flattenArr(ar) {
  if (!Array.isArray(ar)) {
    return [ar];
  } else {
    let res = [];
    for (let i = 0; i < ar.length; i++) {
      res = res.concat(flattenArr(ar[i]));
    }
    return res;
  }
}

let resultAr = flattenArr(arrs);
console.log(resultAr); // Output: [1, 2, 3, 4, 9, 8, 7, 23]

//  --- using built in method :-
function flattenArray(arr) {
  return arr.reduce((acc, val) => {
    return acc.concat(Array.isArray(val) ? flattenArray(val) : val);
  }, []);
}

const nestedArray = [1, [2], [[3, 4]], [9, [8, 7, [[23]]]]];
const flattenedArray = flattenArray(nestedArray);
console.log(flattenedArray); // [ 1, 2, 3,  4, 9, 8, 7, 23 ]

// ---------- subsets of string ----
// let str = "dog" // ["d", "do", "dog", "o", "og", "g"]
// // "abcd"
// let subSetsArray = []
// for (let i = 0; i < str.length; i++) {
//     for (let j = i + 1; j < str.length + 1; j++) {
//         subSetsArray.push(str.slice(i, j))
//     }
// }
// console.log(subSetsArray, str);

// --- factorial with recursion
// function fact(n){
//      if(n < 2){
//          return 1
//      }else{
//          return  n *= fact(n - 1)
//      }
//  }
//  console.log(fact(5));

// ---  range with recursion
// function range(a, b){
//      if(b - a === 2){
//          return [a + 1]
//      }else{
//          let list = range(a, b-1)
//          list.push(b - 1)
//          return list;
//      }
//  }
//  console.log(range(2, 9)) // o/p :-  [ 3, 4, 5, 6, 7, 8 ]

// findOut maxNumber of array dont use built in method
// function findMaxNumber(arr) {
//      if (arr.length === 0) {
//          // Handle the case where the array is empty
//          console.log("The array is empty.");
//          return;
//      }
//      // Assume the first element is the maximum
//      let maxNumber = arr[0];

//      for (let i = 1; i < arr.length; i++) {
//          if (arr[i] > maxNumber) {
//              maxNumber = arr[i];
//          }
//      }
//      console.log("The maximum number in the array is: " + maxNumber);
//  }
//  let numbers = [5, 2, 100,  9, 1, 7, 6, 10];
//  findMaxNumber(numbers);

// -- find unique values of this Two arays
// let arrOne = [ 1, 2, 3, 4, 5, 6 ]
// let arrTwo = [ 5, 6, 7, 8, 9 ]
// let finalArr = [ ...arrOne, ...arrTwo ]
// let uniqueVal = finalArr.filter((curElem, ind, selfArr) => {
//      return  selfArr.indexOf(curElem) ===  ind
// })
// console.log(uniqueVal);
// OutPut :- [ 1, 2, 3, 4, 5, 6, 7, 8, 9 ]

// --- without using filter method
// let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 6, 5];
// let uniqueArray = [];
// for (let i = 0; i < arr.length; i++) {
//     if (uniqueArray.indexOf(arr[i]) === -1) {
//         // If the element is not already in uniqueArray, add it
//         uniqueArray.push(arr[i]);
//     }
// }
// console.log(uniqueArray); // [ 1, 2, 3, 4, 5, 6, 7, 8, 9 ]

// find HCF of two numbers
// let num1 = 60;
// let num2 = 72;
// let HCF = 0
// for(let i = 0; i <= num1 && i <= num2; i++){
//     if(num1 % i === 0 && num2 % i === 0){
//         HCF = i
//     }
// }
// console.log(HCF)

///// ----  Find LCM of the Number
// let num1 = 60;
// let num2 = 72;
// let LCM = 0
// let min = num1 < num2 ? num1 : num2
// while(true){
//     if( min % num1 === 0 && min % num2 === 0 ){
//         LCM = min;
//         break;
//     }
//     min++;
// }
// console.log(LCM)
