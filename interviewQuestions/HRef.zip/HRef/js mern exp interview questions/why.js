///////----------- Dont know why reduce method return different outputs..
let str = [2, 3, 4];
const ftStr = str.reduce(
  (accumulator, cur, index) => accumulator + Math.pow(cur, 2),
  0
); // o/p is 29 // which also squared  1st element of array

const newStr = str.reduce((accumulator, cur, index) => {
  console.log(cur, accumulator);
  // return accumulator += Math.pow(cur, 2), 0 // O/p 0
  return (accumulator += Math.pow(cur, 2)); // o/p 27
}); // o/p is 27 // which not squred 1st element of array

console.log(ftStr, newStr); // 29 27
