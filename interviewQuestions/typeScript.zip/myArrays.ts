// 4rth
//  ---- ways for defining array type ----
const superHeros: string[] = [];
const heroPower: number[] = [];
// const heroPow: Array<number> = []; // working same like heroPower

type User = {
  name: string;
  isActive: boolean;
};

const user: User[] = [];

superHeros.push("thor");
heroPower.push(23);
user.push({ name: "harsh", isActive: false });

console.log("superHeros", superHeros, "heroPower", heroPower, "user", user);

const MlModels: number[][] = [];

// MlModels.push([""]); // error TS2322: Type 'string' is not assignable to type 'number'.
MlModels.push([1, 2, 3], [4, 5, 6]);

console.log("MlModels", MlModels);

// ------ myUnion.ts
