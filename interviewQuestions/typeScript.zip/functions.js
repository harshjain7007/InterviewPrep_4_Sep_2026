"use strict";
// 2nd
// ---------- passed more accurate arguments inside functions  --------
// function addTwo(num1) {
//   num1.toUpperCase(); // TypeError: num1.toUpperCase is not a function
//   return num1 + 2;
// }
// console.log(addTwo(5)); // if we hover this addTwo then its type is any
Object.defineProperty(exports, "__esModule", { value: true });
// write this code
// function addTwo(num1: string) { // we need to defined arguments data type
//   num1.toUpperCase();
//   return num1 + 2;
// }
// console.log(addTwo("jh")); // jh2
// function signUp(name: string, email: string, isPaid: boolean) {
//   return isPaid ? name : email;
// }
// signUp("name", "email@email.com"); // - error TS2554: Expected 3 arguments, but got 2.
// const login = (name: string, email: string, isPaid: boolean = true) => {
//   // way of passing defhault arguments
//   return isPaid ? name : email;
// };
// login("name", "email@email.com");
// -----------  return more accurate value from function  ------
// function func(num: number): number {
//   // difine type return value
//   //   return "str"; // - error TS2322: Type 'string' is not assignable to type 'number'.
//   return num + 10; // 15
// }
// let myVal = func(5);
// console.log(myVal);
var getHello = function (num) {
    return "jnjn";
};
// let arr = ["thor", "spider", "ironman"];
// arr.map((hero): number => `Hero is ${hero}`); // error TS2322: Type 'string' is not assignable to type 'number'.
// if you can't return anything then use void
function consoleErro(errMjs) {
    console.log(errMjs);
    // return 1; // error TS2322: Type 'number' is not assignable to type 'void'.
}
consoleErro("Something went wrong");
// if you can't return anything and create new error then use never
function consoleErroNver(errMjs) {
    // console.log(errMjs);
    // return 1; // error TS2322: Type 'number' is not assignable to type 'never'.
    throw new Error(errMjs);
}
consoleErroNver("Something went wrong");
