// 1st

// let obj = { name: "harsh", age: 23 };
// let ss = obj.email; // they give red line bcz of this line but js not give error
// console.log(obj);

// let numerOne = 33;
// let numberTwo = "67";
// console.log(numerOne + numberTwo); // 3367 gives e

// console.log(12 + "435"); // 1243

// --- For Decerlation of variable ----
// let variableName: number = 20;
// console.log(variableName);
// for good practice we dont need to write type of variable during decelaration of variable bcz of Type inference in TypeScript refers to the compiler's ability to automatically deduce the types of variables,

// let str: string;
// str = 33; //  error TS2322: Type 'number' is not assignable to type 'string'.
// console.log(str); // error TS2454: Variable 'str' is used before being assigned.

// let str: string = "harsh";
// console.log(str.toUpperCase()); // HARSH
// // let num = 34
// // console.log(num..toUpperCase()); // TSError: ⨯ Unable to compile TypeScript:

// let str: string = "harsh";
// console.log(str.toUppercase()); // if you hover toUppercase that mehtod than which is suugest you correct its mehtod name

// in TS int and float is not differant dataTypes all is simple numbers
// let num : number = 32;
// let num2 : number = 32.33;

// boolean
// let bool: boolean = false; // true/false both are boolean data types

// any :- TypeScript also has a special type, any, that you can use whenever you don’t want a particular value to cause typechecking errors. Note :- try to  avoid any bcz any avoid all stricness of typescript
// let hero;
// function fun() {
//   return true;
// }
// hero = fun(); // hover hero which give any data type
// console.log(hero);  // true / with boolean value

// in that case : for good practice you need to define type of hero
// let hero: string;
// function fun() {
//   return true;
// }
// hero = fun(); // error TS2322: Type 'boolean' is not assignable to type 'string'.

// -------- Functions in typeScript -----

export {};
