console.log("run...");

// interface implements any classes and that follows interfcae protocols

interface TakePhoto {
  cameraMode: string;
  filter: string;
  burst: number;
}

class Instagram implements TakePhoto {
  constructor(
    public cameraMode: string,
    public filter: string,
    // public burst: string // if you not follow its protocols then which gives error || error TS2420: Class 'Instagram' incorrectly implements interface 'TakePhoto'.
    public burst: number
  ) {}
}

interface Story {
  createStory(): void;
}

class Youtube implements TakePhoto, Story {
  constructor(
    public cameraMode: string,
    public filter: string,
    public burst: number,
    public short: string // allow to add more protocols but not allow to follow less protocols for implementing extra featuers
  ) {}

  createStory(): void {
    console.log("Story was created");
  }
}
