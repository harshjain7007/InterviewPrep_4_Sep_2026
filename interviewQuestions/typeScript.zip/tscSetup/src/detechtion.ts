// -- thats a function for typeDetechtion :---
function detechType(val: number | string) {
  //   val.toLowerCase(); // error TS2339: Property 'toLowerCase' does not exist on type 'string | number'.
  if (typeof val === "string") {
    return val.toLowerCase();
  }
  return val + 3;
}

// one more approche :-
function providedId(id: string | null) {
  if (!id) {
    console.log("please provided id");
    return;
  }
  id.toLowerCase();
}

// type guards || norrowing
function printAll(strs: string | string[] | null) {
  if (strs) {
    if (typeof strs === "object") {
      for (const s of strs) {
        console.log("ssss", s);
      }
    } else if (typeof strs === "string") {
      console.log("strs else if", strs);
    }
  } else {
    console.log("empty string", strs);
  }
}

console.log("str==>", printAll(""));

// ----- The in Operator Narrowing
interface User {
  name: string;
  email: string;
}

interface Admin {
  name: string;
  email: string;
  isAdmin: boolean;
}

function isAdminAccount(account: User | Admin) {
  //   return account.isAdmin;  // error TS2339: Property 'isAdmin' does not exist on type 'User | Admin'.
  if ("isAdmin" in account) {
    // we are narrowing it using in property || in operator narrowing
    return account.isAdmin;
  }
}

// ----  instanceof narrowing
function logValue(x: Date | string) {
  if (x instanceof Date) {
    // instanceof used with new keyword like new Date()
    console.log(x.toUTCString());
  } else {
    console.log(x.toUpperCase());
  }
}

// --------- Using type predicates---
type Fish = { swim: () => void };
type Bird = { fly: () => void };

function isFish(pet: Fish | Bird): pet is Fish {
  return (pet as Fish).swim !== undefined;
} // its return true or false not return type of pet

function getFood(pet: Fish | Bird) {
  if (isFish(pet)) {
    pet;
    return "fish food";
  } else {
    pet;
    return "bird Food";
  }
}

// ---- Discriminated Union -------
interface Circle {
  kind: "circle";
  radius: number;
}

interface Square {
  kind: "square";
  radius: number;
  side: number;
}

interface Rectangle {
  kind: "rectangle";
  length: number;
  width: number;
}

type Shape = Circle | Square | Rectangle;

function getTrueShape(shape: Shape) {
  if (shape.kind === "circle") {
    return Math.PI * shape.radius ** 2;
  }
  // return shape.side * shape.side; // error TS2339: Property 'side' does not exist on type 'Square | Rectangle'.
}

function getArea(shape: Shape) {
  switch (shape.kind) {
    case "circle":
      return Math.PI * shape.radius ** 2;
    case "square":
      return shape.side * shape.side;
    case "rectangle":
      return shape.length * shape.length;
    default:
      const _defaultforshape: never = shape; // type never
      return _defaultforshape;
  }
}
