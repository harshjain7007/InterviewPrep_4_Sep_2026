"use strict";

// How we can created classes using typeSCript

// For Creating Constructor :-
// class User {
//   email: string;
//   name: string;
//   city: string = "";
//   private namePrivate = "private"; // private mean which is not accesble || in JS we apply that thing like #name
//   public namePublic = "public";
//   readonly code: number = 123;
//   constructor(email: string, name: string) {
//     this.email = email;
//     this.name = name;
//   }
// }

// produce same code
class User {
  city: string = "";
  readonly code: number = 123;
  constructor(
    email: string,
    name: string,
    private userId: number,
    private namePrivate = "private",
    public namePublic = "public"
  ) {}
  get getApplyEmail(): string {
    return `apple ${this.namePublic}`;
  }
}

// const harsh = new User("h@gmail.com", 123, "harsh"); // error TS2345: Argument of type 'number' is not assignable to parameter of type 'string'.
const harsh = new User("h@gmail.com", "harsh", 123);
// harsh.city = 3; // error TS2322: Type 'number' is not assignable to type 'string'.
harsh.city = "Indore";
// harsh.code = 999; // error TS2540: Cannot assign to 'code' because it is a read-only property.
console.log("harsh", harsh);

console.log(harsh.namePublic); //
// console.log(harsh.namePrivate); // error TS2341: Property 'namePrivate' is private and only accessible within class 'User'.

// if we want to set private values then we have some setter for this ( getters & setters )
// Example :-

class MyUser {
  private _courseCount = 1;
  constructor(private name = "") {}

  private deleteToken() {
    console.log("Token deleted");
  }

  get courseCount(): number {
    // getter
    return this._courseCount;
  }

  set courseCount(courseNum) {
    // we access variable inside class only out side class
    // setter
    if (courseNum <= 1) {
      throw new Error("Course count should be more than 1");
    }
    this._courseCount = courseNum;
  }
}

let myUser = new MyUser();

console.log("myUser", myUser);

// ------  inheritance use another class to another class ------

class ParentUser {
  protected course_count: number = 5; // this key is accessible any class which is iherits its property
}

class SubUser extends ParentUser {
  isFamily: boolean = true;
  changeCourseCount() {
    this.course_count = 5;
  }
}

let subUser = new SubUser();
console.log("subUser", subUser); // SubUser {course_count: 5, isFamily: true}
