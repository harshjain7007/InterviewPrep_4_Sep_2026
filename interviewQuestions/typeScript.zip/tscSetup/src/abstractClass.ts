// #3rd
abstract class TakePhotos {
  constructor(public cameraMode: string, public filter: string) {}
  abstract getSepia(): void;
  getReelTime(): number {
    // some complex calculation
    return 8;
  }
}

// let hc = new TakePhoto("camera mode", "filter"); //  error TS2511: Cannot create an instance of an abstract class.

class Insta extends TakePhotos {
  //  if you want to create object from abstract class then we need extends thats property into any class
  constructor(
    public cameraMode: string,
    public filter: string,
    public burst: number
  ) {
    super(cameraMode, filter);
  }

  getSepia(): void {
    // this method cant override same previous method bcz its define with abstract class
    console.log("Sepia");
  }

  //   getReelTime(): number {
  //     return 10;
  //   }
}

let hc = new Insta("camera mode", "filter", 8);
console.log("hcc", hc.getSepia()); // hcc undefined
