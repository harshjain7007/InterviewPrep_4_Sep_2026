// Generix  like which makes components reuseble
const score: Array<number> = [];
const names: Array<string> = [];

// 1st way simple
function identityOne(val: boolean | number): boolean | number {
  return val;
}

// 2nd way : thats not a good way
function identityTwo(val: any): any {
  return val;
}

// 3rd :  use Type  thats good
function identityThree<Type>(val: Type): Type {
  return val;
} // if you passed string then which automatically consume return type string, if you passed number then return type is number , if passed boolean then return type is boolean value

identityThree(3); // hover this
identityThree("str"); // hover this
identityThree(true); // hover this

function identityFour<T>(val: T): T {
  return val;
}

interface Bootle {
  brand: string;
  type: number;
}

// identityFour<Bootle>({})

function getSearchProducts<T>(products: T[]): T {
  // T[] which means type of any of this array
  // if you mention return type T which means that return one of the value from this array
  //   return 3; // error TS2322: Type 'number' is not assignable to type 'T'.

  // do some data base operation
  const myIndex = 3;
  return products[myIndex]; // its working
}

console.log(getSearchProducts([1, 2, 3, 4, 5])); // 4

//  if you used arrow function then write like this
const getMoreSearchProducts = <T>(products: T[]): T => {
  // do some database operations
  const myIndex = 4;
  return products[myIndex];
};
getMoreSearchProducts([1, 2, 3, 4, 5]);

interface Database {
  connection: string;
  username: string;
  password: string;
}

function anotherFunction<T, U extends number>(valOne: T, valTwo: U): object {
  return {
    valOne,
    valTwo,
  };
}

// anotherFunction(3, "4"); // error TS2345: Argument of type 'string' is not assignable to parameter of type 'number'.

anotherFunction(3, 4);

interface Quiz {
  name: string;
  type: string;
}

interface Course {
  name: string;
  author: string;
  subject: string;
}

// we want to create a class which can handle some of the comon cases
class Sellable<T> {
  // this class is handlled a comon use cases of both of them
  public cart: T[] = [];
  addToCart(product: T) {
    this.cart.push(product);
  }
}

let v = new Sellable();
console.log("v", v.addToCart("l")); // v undefined
console.log("v", v.cart); // v [ 'l' ]
