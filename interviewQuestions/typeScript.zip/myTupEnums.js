"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// 6th
// Tuples like more stric then array we can set data in array order form
var tupArr;
tupArr = ["hj", 23, true];
var newUser = [112, "h@gmail.com"];
newUser[1] = "harsh@gmail.com";
// newUser.push(true); // error TS2345: Argument of type 'boolean' is not assignable to parameter of type 'string | number'.
newUser.push("new"); // push , pop , shift , unshift , slice this array mehtod is working
console.log("newUser==>", newUser);
// -----  Enums.ts  ----
var SeatChoice;
(function (SeatChoice) {
    SeatChoice["AISLE"] = "aisle";
    SeatChoice[SeatChoice["MIDDLE"] = 1] = "MIDDLE";
    SeatChoice[SeatChoice["WINDOW"] = 2] = "WINDOW";
    SeatChoice[SeatChoice["FOURTH"] = 3] = "FOURTH";
})(SeatChoice || (SeatChoice = {}));
var hcSeat = SeatChoice.AISLE;
var hcSeatTwo = SeatChoice.WINDOW;
console.log("hcSeat", hcSeat, "hcSeatTwo", hcSeatTwo);
