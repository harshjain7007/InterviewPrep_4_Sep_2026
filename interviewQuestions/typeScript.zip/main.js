// let obj = { name: "harsh", age: 23 };
// let ss = obj.email; // they give red line bcz of this line but js not give error
// console.log(obj);
// let numerOne = 33;
// let numberTwo = "67";
// console.log(numerOne + numberTwo); // 3367 gives e
// console.log(12 + "435"); // 1243
// --- For Decerlation of variable ----
var variableName = 20;
console.log(variableName);
