// 3rd

const user = {
  name: "harsh",
  email: "harsh@gmail.com",
  isActive: true,
};

function createCourse(): { name: string; price: number } {
  return { name: "react", price: 399 };
}
console.log(createCourse());

// some miss behaivor of functions in typeScript For Example :-
// function createUser({ name: string, isPaid: boolean }) {
//   // its working dont why give red line
//   console.log("run user..");
// }
// createUser({ name: "has", isPaid: false, email: "h@gmail.com" }); // error TS2353: Object literal may only specify known properties, and 'email' does not exist in type '{ name: any; isPaid: any; }'.

// if we give custom object then it not give error
function createUserAdd({ name: string, isPaid: boolean }) {
  console.log("run user..");
}
let obj = { name: "has", isPaid: false, email: "h@gmail.com" };
createUserAdd(obj);

// ------ Type alias in TSX ----
type User = {
  name: string;
  email: string;
  isActive: boolean;
};

function createUser(user: User): User {
  // this function gets User types of data and also return same User types object
  return user;
}
createUser({ name: "", email: "", isActive: true });

// ------- keyword Read only || Literal ? || use Case Senario -----
type newUser = {
  readonly _id: string; // readonly which means we can't modified that _id, in js file not show readonly property
  name: string;
  email: string;
  isActive: boolean;
  creaditCard?: number; // Question mark which means this is optional
};

let myUser: newUser = {
  _id: "123",
  name: "harsh",
  email: "h@hgmail.com",
  isActive: true,
};

myUser.email = "new@gmail.com"; // its allow us to change
// myUser._id = "12345"; // error TS2540: Cannot assign to '_id' because it is a read-only property.
console.log("myUser", myUser);

// -----
type cardNumber = {
  cardnumber: string;
};

type cardDate = {
  cardDate: string;
};

type cardDetail = cardNumber &
  cardDate & {
    // cardDetail contain all property bcz of &
    cvv: number;
  };

// --- myArrays.ts -----

export {};
