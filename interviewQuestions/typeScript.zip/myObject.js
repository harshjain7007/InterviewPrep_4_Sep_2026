"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var user = {
  name: "harsh",
  email: "harsh@gmail.com",
  isActive: true,
};
function createCourse() {
  return { name: "react", price: 399 };
}
console.log(createCourse());
// some miss behaivor of functions in typeScript For Example :-
// function createUser({ name: string, isPaid: boolean }) {
//   // its working dont why give red line
//   console.log("run user..");
// }
// createUser({ name: "has", isPaid: false, email: "h@gmail.com" }); // error TS2353: Object literal may only specify known properties, and 'email' does not exist in type '{ name: any; isPaid: any; }'.
// if we give custom object then it not give error
function createUserAdd(_a) {
  var string = _a.name,
    boolean = _a.isPaid;
  console.log("run user..");
}
var obj = { name: "has", isPaid: false, email: "h@gmail.com" };
createUserAdd(obj);
function createUser(user) {
  // this function gets User types of data and also return same User types object
  return user;
}
createUser({ name: "", email: "", isActive: true });
var myUser = {
  _id: "123",
  name: "harsh",
  email: "h@hgmail.com",
  isActive: true,
};
myUser.email = "new@gmail.com"; // its allow us to change
myUser._id = "12345"; // error TS2540: Cannot assign to '_id' because it is a read-only property.
console.log("myUser", myUser);
