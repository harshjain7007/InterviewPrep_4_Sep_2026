"use strict";
// 5th
// instead of any try to use union, which working like any
// if you dont what thetype of data is coming then use it
Object.defineProperty(exports, "__esModule", { value: true });
var score = 34;
score = "str";
console.log("score", score);
score = false;
console.log("score", score);
var harsh = { name: "name", id: 223 };
harsh = { userName: "username", id: 332, age: 24 };
console.log("harsh", harsh); // harsh { userName: 'username', id: 332, age: 24 }
// -----------
function getDbId(id) {
    console.log("Db id is ".concat(id));
    //   id.toUpperCase(); // error TS2339: Property 'toUpperCase' does not exist on type 'string | number'.
    if (typeof id === "string") {
        id.toUpperCase(); // if you hover id then check they give id is 100% string
    }
    else {
        id + 2; // if you hover id then check they give id is 100% number
    }
}
getDbId(34);
getDbId("str");
var arrOne = [1, 2, 3];
var arrTwo = ["1", "2", "3"];
// const arrThree: number[] | string[] = [1, 2, 3, "str"]; // error TS2322: Type '(string | number)[]' is not assignable to type 'string[] | number[]'.
var arrThree = [1, 2, 3, "str", false]; // instead of this  (number | string | boolean)[] we can also use any[] but dont use this bcz its reduce stricness of our code
// let pi: 3.14 = 3.14;
// pi = 3.145; // error TS2322: Type '3.145' is not assignable to type '3.14'.
var seatAllotment;
seatAllotment = "aisle";
seatAllotment = "";
