console.log("print somthing ");
