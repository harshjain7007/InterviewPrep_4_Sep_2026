let str: string = "knkn";

console.log(str);

export {};
