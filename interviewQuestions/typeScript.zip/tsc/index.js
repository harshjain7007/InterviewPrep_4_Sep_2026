var str = "knkn";
console.log(str);
