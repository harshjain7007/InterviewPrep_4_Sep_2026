//  7th
interface User {
  readonly dbId: number;
  email: string;
  userId: number;
  googleId?: string;
  startTrail(): string; // for define method
  //   startTrail: () => string; // one more way for define method
  getCoupon(couponname: string, value: number): number;
}

interface User {
  // peoples called it like reOpening of interface
  githubToken: string;
}

interface Admin extends User {
  //  with this extend keyword we can easily access User interfaces || if you want to use another interface with User interface then write line like  , interface Admin extends User, anotherInterfaceName
  role: "admin" | "ta" | "lean";
}

const harsh: Admin = {
  dbId: 22,
  email: "h@gmail.com",
  userId: 2211,
  startTrail: () => "trail started",
  getCoupon: (name: "harsh", off: 10) => {
    // don't need to pass same argument name according to Uesr
    return 10;
  },
  githubToken: "gitHub",
  role: "admin",
};

console.log("harsh ");

export {};
