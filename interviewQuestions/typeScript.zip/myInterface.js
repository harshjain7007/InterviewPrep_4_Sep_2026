"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var harsh = {
    dbId: 22,
    email: "h@gmail.com",
    userId: 2211,
    startTrail: function () { return "trail started"; },
    getCoupon: function (name, off) {
        // don't need to pass same argument name according to Uesr
        return 10;
    },
    githubToken: "gitHub",
    role: "admin",
};
console.log("harsh ");
