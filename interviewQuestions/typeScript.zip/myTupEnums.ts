// 6th
// Tuples like more stric then array we can set data in array order form
let tupArr: [string, number, boolean];
tupArr = ["hj", 23, true];
// tupArr = [23, true, "hj"]; //  error TS2322: Type 'string' is not assignable to type 'boolean'.

// -----------------
type User = [number, string];
const newUser: User = [112, "h@gmail.com"];
newUser[1] = "harsh@gmail.com";
// newUser.push(true); // error TS2345: Argument of type 'boolean' is not assignable to parameter of type 'string | number'.
newUser.push("new"); // push , pop , shift , unshift , slice this array mehtod is working
console.log("newUser==>", newUser);

// -----  Enums.ts  ----
enum SeatChoice {
  AISLE = "aisle",
  MIDDLE = 1,
  WINDOW,
  FOURTH,
}

const hcSeat = SeatChoice.AISLE;
const hcSeatTwo = SeatChoice.WINDOW;
console.log("hcSeat", hcSeat, "hcSeatTwo", hcSeatTwo);

// ---- myInterface.ts ---
export {};
